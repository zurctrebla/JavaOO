
class Enfermaria {

  private int secao;

  public Enfermaria(int secao){

    this.secao = secao;
  }

  public int getSecao() {
    return secao;
  }
}
