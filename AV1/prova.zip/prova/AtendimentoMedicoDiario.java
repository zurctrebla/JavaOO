import java.util.ArrayList;
import java.util.Date;
import java.util.List;

class AtendimentoMedicoDiario {
  
  private String sintomas;

  private String diagnostico;

  private Date dataAtendimento;

  private Object medico;

  private List<TipoDoenca> tiposDoenca;

  private char tipoAcomodacao;

  private char tipoMedico;

  private List<CirurgiaMedica> cirurgias;

  private List<ProcedimentoMedico> procedimentos;

  private List<ExameMedico> exames;

  private List<ConsultaMedica> consultas;

  private Object acomodacao;

  private Paciente paciente;

  public AtendimentoMedicoDiario(Paciente paciente, Object acomodacao, Object medico){

    this.paciente = paciente;
    this.setAcomodacao(acomodacao);
    this.setMedico(medico);

    tiposDoenca = new ArrayList<TipoDoenca>();
    cirurgias = new ArrayList<CirurgiaMedica>();
    procedimentos = new ArrayList<ProcedimentoMedico>();
    exames = new ArrayList<ExameMedico>();
    consultas = new ArrayList<ConsultaMedica>();
  }

  public String getSintomas() {

    return Util.semAcento(sintomas).toLowerCase();
  }

  public void setSintomas(String sintomas) {
    this.sintomas = sintomas;
  }

  public String getDiagnostico() {
    
    return Util.semAcento(diagnostico).toLowerCase();
  }

  public void setDiagnostico(String diagnostico) {
    this.diagnostico = diagnostico;
  }

  public Date getDataAtendimento() {
    return dataAtendimento;
  }

  public void setDataAtendimento(Date dataAtendimento) {
    this.dataAtendimento = dataAtendimento;
  }

  public Object getMedico() {
    return medico;
  }

  public void setMedico(Object medico) {
    
    this.medico = medico;

    if (medico instanceof MedicoClinicoGeral)
      this.tipoMedico = 'C';
    else  
      this.tipoMedico = 'E';
  }

  public List<TipoDoenca> getTiposDoenca() {
    return tiposDoenca;
  }

  public void addTipoDoenca(TipoDoenca tipoDoenca) {
  
    tiposDoenca.add(tipoDoenca);
  }

  public char getTipoAcomodacao() {

    return Character.toLowerCase(tipoAcomodacao);
  }

  public char getTipoMedico() {

    return Character.toLowerCase(tipoMedico);
  }

  public List<CirurgiaMedica> getCirurgias() {
    return cirurgias;
  }

  public void addCirurgia(CirurgiaMedica cirurgia) {

    cirurgias.add(cirurgia);
  }

  public List<ProcedimentoMedico> getProcedimentos() {
    return procedimentos;
  }

  public void addProcedimento(ProcedimentoMedico procedimento) {

    procedimentos.add(procedimento);
  }

  public List<ConsultaMedica> getConsultas() {
    return consultas;
  }

  public void addConsulta(ConsultaMedica consulta) {
    
    consultas.add(consulta);
  }

  public List<ExameMedico> getExames() {
    return exames;
  }

  public void addExame(ExameMedico exame) {
  
    exames.add(exame);
  }

  public Object getAcomodacao() {
    return acomodacao;
  }

  public void setAcomodacao(Object acomodacao) {

    this.acomodacao = acomodacao;

    if (acomodacao instanceof Quarto)
      this.tipoAcomodacao = 'Q';
    else  
      this.tipoAcomodacao = 'E';    
  }
}
