
class ValorMaximoAtendimentoDiarioAtingidoException extends Exception {

    public ValorMaximoAtendimentoDiarioAtingidoException(){
        
        super("Valor do custo total do atendimento diário ao paciente definido pelo plano de saúde foi excedido!");
    }      
}
