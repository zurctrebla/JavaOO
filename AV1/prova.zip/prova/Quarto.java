
class Quarto {
  
  private int telefone;

  private int numero;

  public Quarto(int numero, int telefone){

    this.numero = numero;
    this.telefone = telefone;
  }

  public int getTelefone() {
    return telefone;
  }

  public int getNumero() {
    return numero;
  }

}
