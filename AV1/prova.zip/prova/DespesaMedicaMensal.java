
class DespesaMedicaMensal {

  private Paciente paciente;
  private final double valorDiariaQuarto = 200; 
  private final double valorDiariaEnfermaria = 100; 

  public DespesaMedicaMensal(Paciente paciente){

    this.paciente = paciente;
  }

  public double getValorDiariaQuarto(){

   return this.valorDiariaQuarto;
  }

  public double getValorDiariaEnfermaria(){

    return this.valorDiariaEnfermaria;
  }
}
