
class ValorMaximoDespesaMensalAtingidaException extends Exception {

    public ValorMaximoDespesaMensalAtingidaException(){
        
        super("Valor do custo total sobre todas as diárias do paciente definido pelo plano de saúde foi excedido!");
    }      

}
